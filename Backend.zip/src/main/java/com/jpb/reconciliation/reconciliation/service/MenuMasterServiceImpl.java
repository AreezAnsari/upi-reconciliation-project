package com.jpb.reconciliation.reconciliation.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.jpb.reconciliation.reconciliation.constants.MenuConstants;
import com.jpb.reconciliation.reconciliation.dto.ReconMenuMasterDto;
import com.jpb.reconciliation.reconciliation.dto.ResponseDto;
import com.jpb.reconciliation.reconciliation.dto.RestWithStatusList;
import com.jpb.reconciliation.reconciliation.entity.ReconFileDetailsMaster;
import com.jpb.reconciliation.reconciliation.entity.ReconMenuMaster;
import com.jpb.reconciliation.reconciliation.entity.v2.ReconRoleMaster;
import com.jpb.reconciliation.reconciliation.entity.v2.ReconUser;
import com.jpb.reconciliation.reconciliation.exception.ResourceNotFoundException;
import com.jpb.reconciliation.reconciliation.mapper.ReconMenuMasterMapper;
import com.jpb.reconciliation.reconciliation.repository.MenuMasterRepository;
import com.jpb.reconciliation.reconciliation.repository.ReconFileDetailsMasterRepository;
import com.jpb.reconciliation.reconciliation.constants.UserConstants;
import com.jpb.reconciliation.reconciliation.repository.v2.CRoleMenuMapRepository;
import com.jpb.reconciliation.reconciliation.repository.v2.ReconRoleMasterRepository;
import com.jpb.reconciliation.reconciliation.repository.v2.ReconRoleProductMapRepository;
import com.jpb.reconciliation.reconciliation.repository.v2.ReconUserRepository;

@Service
public class MenuMasterServiceImpl implements MenuMasterService {

    // Fixed Master-menu sequence for the Sidebar — same for every role, regardless of which
    // order privileges were granted in. Anything not listed here (custom Masters an Admin
    // creates via Add Menu) sorts after these, via the default(99) fallback.
    private static final Map<String, Integer> MASTER_GROUP_ORDER = new HashMap<>();
    static {
        MASTER_GROUP_ORDER.put("Dashboard", 0);
        MASTER_GROUP_ORDER.put("My Organization", 1);
        MASTER_GROUP_ORDER.put("Administration", 2);
    }

    @Autowired
    MenuMasterRepository menuMasterRepository;

    @Autowired
    AuditLogManagerService auditLogManagerService;

    @Autowired
    ReconUserRepository reconUserRepository;

    @Autowired
    ReconFileDetailsMasterRepository fileDetailsMasterRepository;

    @Autowired
    EmailService emailService;

    @Autowired
    ReconRoleMasterRepository reconRoleMasterRepository;

    @Autowired
    CRoleMenuMapRepository roleMenuMapRepository;

    @Autowired
    ReconRoleProductMapRepository roleProductMapRepository;

    Logger logger = LoggerFactory.getLogger(MenuMasterServiceImpl.class);

    @Override
    public ResponseEntity<RestWithStatusList> getMenus(Long menuId) {
        List<Object> menuData = new ArrayList<>();
        ReconMenuMaster menu = menuMasterRepository.findByMenuId(menuId)
                .orElseThrow(() -> new ResourceNotFoundException("Menu not found :" + menuId));
        ReconMenuMasterDto menuDto = ReconMenuMasterMapper.mapToMenuDto(menu, new ReconMenuMasterDto());
        menuData.add(menuDto);
        return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu found successfully", menuData), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResponseDto> removeMenu(Long menuId) {
        ReconMenuMaster menu = menuMasterRepository.findByMenuId(menuId)
                .orElseThrow(() -> new ResourceNotFoundException("MENU NOT FOUND :" + menuId));
        List<ReconMenuMaster> existsParentMenuList = menuMasterRepository.findByParentMenuCode(menu.getMenuType());
        if (existsParentMenuList.isEmpty()) {
            menuMasterRepository.deleteById(menu.getMenuId());
        } else {
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
                    .body(new ResponseDto(MenuConstants.STATUS_417, "Please delete the submenu first."));
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ResponseDto(MenuConstants.STATUS_200, "Menu Removed Successfully"));
    }

    @Override
    public boolean updateMenu(ReconMenuMasterDto menuDto) {
        Optional<ReconMenuMaster> opt = menuMasterRepository.findById(menuDto.getMenuId());
        if (!opt.isPresent()) return false;
        ReconMenuMasterMapper.mapToMenu(menuDto, opt.get());
        menuMasterRepository.save(opt.get());
        return true;
    }

    @Override
    public ResponseEntity<RestWithStatusList> getAllMenus() {
        List<ReconMenuMaster> fetchMenuData = menuMasterRepository.findAll();
        List<Object> menuList = new ArrayList<>(fetchMenuData);
        if (!fetchMenuData.isEmpty()) {
            return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu details found successfully", menuList), HttpStatus.OK);
        }
        return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Menu details not found", null), HttpStatus.NOT_FOUND);
    }

    @Override
    public ResponseEntity<RestWithStatusList> getMenuByUserId(Long userId) {
        List<Object> menuList = new ArrayList<>();
        List<ReconMenuMaster> menuByUserId = menuMasterRepository.getByInsertUserId(userId);
        if (menuByUserId.isEmpty()) {
            return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Menu details not found", menuList), HttpStatus.NOT_FOUND);
        }
        for (ReconMenuMaster menu : menuByUserId) {
            ReconFileDetailsMaster fileData = fileDetailsMasterRepository.findByReconFileId(menu.getMenuProcessId());
            menuList.add(ReconMenuMasterMapper.mapToMenuDtoWithFilePath(new ReconMenuMasterDto(), menu, fileData));
        }
        return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu details found successfully", menuList), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RestWithStatusList> addMenu(ReconMenuMasterDto menuRequest, UserDetails userDetails) {
        try {
            ReconMenuMaster menuWithName = menuMasterRepository.findByMenuNameAndRoleIdAndParentMenuCode(
                    menuRequest.getMenuName(), menuRequest.getRoleId(), menuRequest.getParentMenuCode());

            Optional<ReconUser> userOpt = reconUserRepository.findByUsername(userDetails.getUsername());
            if (!userOpt.isPresent()) {
                return new ResponseEntity<>(new RestWithStatusList("FAILURE", "User not found", null), HttpStatus.BAD_REQUEST);
            }
            ReconUser userData = userOpt.get();

            if (menuWithName != null &&
                (menuWithName.getParentMenuCode() != null && menuWithName.getParentMenuCode().equalsIgnoreCase(menuRequest.getParentMenuCode())
                || menuWithName.getMenuName().equalsIgnoreCase(menuRequest.getMenuName()))) {
                return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Menu already exists for this role", null), HttpStatus.BAD_REQUEST);
            }

            ReconMenuMaster createdMenu = createMenu(menuRequest, userData.getUsername());

            ReconFileDetailsMaster getFileData = fileDetailsMasterRepository.findByReconFileId(menuRequest.getMenuProcessId());
            if (getFileData != null) {
                getFileData.setReconExitMenuFlag("Y");
                fileDetailsMasterRepository.save(getFileData);
            }
            auditLogManagerService.commonAudit(userData, "Add MENU", createdMenu);
            return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu Created Successfully",
                    java.util.Collections.singletonList(createdMenu)), HttpStatus.CREATED);

        } catch (Exception e) {
            logger.error("Exception while creating menu: " + e.getMessage(), e);
            return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Exception occurred while creating menu: " + e.getMessage(), null), HttpStatus.BAD_REQUEST);
        }
    }

    @Override
    public ResponseEntity<RestWithStatusList> addMenuActive(ReconMenuMasterDto menuRequest, UserDetails userDetails) {
        try {
            Optional<ReconUser> userOpt = reconUserRepository.findByUsername(userDetails.getUsername());
            if (!userOpt.isPresent()) {
                return new ResponseEntity<>(new RestWithStatusList("FAILURE", "User not found", null), HttpStatus.BAD_REQUEST);
            }
            ReconUser userData = userOpt.get();
            if (!com.jpb.reconciliation.reconciliation.constants.UserConstants.isAdminUserType(userData.getUserType())) {
                return new ResponseEntity<>(new RestWithStatusList("FAILURE",
                        "Only a Bank/Branch/KAL Admin can create a Menu that activates immediately.", null), HttpStatus.FORBIDDEN);
            }

            ReconMenuMaster menuWithName = menuMasterRepository.findByMenuNameAndRoleIdAndParentMenuCode(
                    menuRequest.getMenuName(), menuRequest.getRoleId(), menuRequest.getParentMenuCode());
            if (menuWithName != null &&
                (menuWithName.getParentMenuCode() != null && menuWithName.getParentMenuCode().equalsIgnoreCase(menuRequest.getParentMenuCode())
                || menuWithName.getMenuName().equalsIgnoreCase(menuRequest.getMenuName()))) {
                return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Menu already exists for this role", null), HttpStatus.BAD_REQUEST);
            }

            String actor = userDetails.getUsername();
            ReconMenuMaster createdMenu = createMenu(menuRequest, "Y", actor, actor, actor);

            ReconFileDetailsMaster getFileData = fileDetailsMasterRepository.findByReconFileId(menuRequest.getMenuProcessId());
            if (getFileData != null) {
                getFileData.setReconExitMenuFlag("Y");
                fileDetailsMasterRepository.save(getFileData);
            }
            auditLogManagerService.commonAudit(userData, "Add MENU", createdMenu);
            return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu created and activated.",
                    java.util.Collections.singletonList(createdMenu)), HttpStatus.CREATED);

        } catch (Exception e) {
            logger.error("Exception while creating active menu: " + e.getMessage(), e);
            return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Exception occurred while creating menu: " + e.getMessage(), null), HttpStatus.BAD_REQUEST);
        }
    }

    private ReconMenuMaster createMenu(ReconMenuMasterDto req, String createdBy) {
        return createMenu(req, "DRAFT", null, null, createdBy);
    }

    private ReconMenuMaster createMenu(ReconMenuMasterDto req, String status, String submittedBy, String approvedBy, String createdBy) {
        ReconMenuMaster m = new ReconMenuMaster();
        m.setMenuType(req.getMenuType());
        m.setMenuName(req.getMenuName());
        m.setMenuDescription(req.getMenuDescription());
        m.setParentMenuCode(req.getParentMenuCode());
        m.setSubMenu(req.getSubMenuReq());
        m.setMasterMenuParent(req.getMasterMenuParent());
        m.setInsertUserId(req.getUserId());
        m.setMenuProcessId(req.getMenuProcessId());
        m.setMenuUrl(req.getMenuUrl());
        m.setProcessType(req.getProcessType());
        m.setStatus(status);
        m.setSubmittedBy(submittedBy);
        m.setApprovedBy(approvedBy);
        m.setRoleId(req.getRoleId());
        m.setCreatedBy(createdBy);
        m.setCreatedDate(new Date());
        m.setInsertDate(new Date());
        menuMasterRepository.save(m);
        return m;
    }

    @Override
    public ResponseEntity<RestWithStatusList> getMenuByRole(Long roleId) {
        List<Object> menuList = new ArrayList<>();
        List<ReconMenuMaster> menuByRole = menuMasterRepository.getByRoleIdAndStatus(roleId, "Y");
        logger.info("Menu data by role: " + menuByRole);
        if (menuByRole.isEmpty()) {
            return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Menu not found for this role", menuList), HttpStatus.NOT_FOUND);
        }
        for (ReconMenuMaster menu : menuByRole) {
            ReconFileDetailsMaster fileData = fileDetailsMasterRepository.findByReconFileId(menu.getMenuProcessId());
            menuList.add(ReconMenuMasterMapper.mapToMenuDtoWithFilePath(new ReconMenuMasterDto(), menu, fileData));
        }
        return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu found successfully", menuList), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RestWithStatusList> getMenusByRolePrivileges(Long roleId) {
        List<Object> menuList = new ArrayList<>();
        List<Long> menuIds = roleMenuMapRepository.findMenuIdsByRoleId(roleId);
        if (menuIds.isEmpty()) {
            return new ResponseEntity<>(new RestWithStatusList("FAILURE", "No privileges assigned to this role", menuList), HttpStatus.NOT_FOUND);
        }
        List<ReconMenuMaster> mapped = menuMasterRepository.findAllById(menuIds).stream()
                .filter(m -> "Y".equals(m.getStatus()))
                .collect(Collectors.toList());

        // Sidebar.jsx only nests a Main-type menu under a Master it can find in this same
        // result set — if Privileges only had the child checked (not its parent Master),
        // the child becomes an orphaned, invisible entry. Pull the parent Master in here too,
        // even though it was never explicitly added to C_ROLE_MENU_MAP for this role.
        Map<Long, ReconMenuMaster> byId = new LinkedHashMap<>();
        for (ReconMenuMaster m : mapped) byId.put(m.getMenuId(), m);

        // Cache the resolved parent PER NAME, resolved once per request — Sidebar.jsx nests by
        // NAME match only, so if two different Main items sharing a parentMenuCode name each
        // independently resolved to a DIFFERENT physical Master row (since MENU_NAME isn't
        // unique — Kal Admin, each Bank Admin, each Branch Admin all have their own
        // "Administration"/"My Organization"), the Sidebar renders one section per row, each
        // duplicating the same children by name. Resolving once and reusing prevents that.
        Map<String, ReconMenuMaster> parentCache = new LinkedHashMap<>();
        for (ReconMenuMaster m : mapped) {
            if (!"Main".equals(m.getMenuType()) || m.getParentMenuCode() == null) continue;
            String parentCode = m.getParentMenuCode();
            ReconMenuMaster parent = parentCache.get(parentCode);
            if (parent == null && !parentCache.containsKey(parentCode)) {
                parent = menuMasterRepository.findAllByMenuNameAndMenuType(parentCode, "Master")
                        .stream().filter(p -> "Y".equals(p.getStatus())).findFirst().orElse(null);
                if (parent == null) {
                    try {
                        parent = menuMasterRepository.findByMenuId(Long.parseLong(parentCode)).orElse(null);
                    } catch (NumberFormatException ignored) {
                        // parentMenuCode isn't numeric — not a legacy ID-based row, nothing to fall back to
                    }
                }
                parentCache.put(parentCode, parent);
            }
            if (parent != null && "Y".equals(parent.getStatus())) {
                byId.putIfAbsent(parent.getMenuId(), parent);
            }
        }

        // Global uniqueness guard: MENU_NAME is not unique for Master rows (Kal Admin, each
        // Bank Admin, each Branch Admin all have their own "My Organization"/"Administration")
        // — if TWO different physical Master rows sharing the same name ever both end up in
        // byId (whether directly mapped in C_ROLE_MENU_MAP, e.g. via the backfill migration, or
        // pulled in as an ancestor above), the Sidebar would render one section per row, each
        // duplicating the same children. Collapse to one Master per name here, regardless of
        // how the duplicate got in — this is the single place that guarantees it everywhere.
        Map<String, Long> firstMasterIdByName = new LinkedHashMap<>();
        for (ReconMenuMaster m : byId.values()) {
            if (!"Master".equals(m.getMenuType())) continue;
            firstMasterIdByName.putIfAbsent(m.getMenuName(), m.getMenuId());
        }
        byId.values().removeIf(m -> "Master".equals(m.getMenuType())
                && !m.getMenuId().equals(firstMasterIdByName.get(m.getMenuName())));

        // Sort into the same sequential order the Admin sees. Master-to-Master order is fixed
        // by name (Dashboard, then My Organization, then Administration, anything else last) —
        // NOT by MENU_ID, since the ancestor-Master lookup above can resolve "My Organization"/
        // "Administration" to whichever same-named row it happens to find first across several
        // bootstrap trees, so their relative MENU_ID order isn't reliable. Within each Master's
        // group, items still sort by MENU_ID (a twin's own ID reflects when it was
        // privilege-assigned, not its canonical position, so TWIN_OF_MENU_ID is used instead).
        List<ReconMenuMaster> ordered = new ArrayList<>(byId.values());
        ordered.sort(Comparator
                .comparing((ReconMenuMaster m) -> MASTER_GROUP_ORDER.getOrDefault(
                        "Master".equals(m.getMenuType()) ? m.getMenuName() : m.getParentMenuCode(), 99))
                .thenComparing(m -> m.getTwinOfMenuId() != null ? m.getTwinOfMenuId() : m.getMenuId()));

        for (ReconMenuMaster menu : ordered) {
            ReconFileDetailsMaster fileData = fileDetailsMasterRepository.findByReconFileId(menu.getMenuProcessId());
            menuList.add(ReconMenuMasterMapper.mapToMenuDtoWithFilePath(new ReconMenuMasterDto(), menu, fileData));
        }
        return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu found successfully", menuList), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RestWithStatusList> submitForApproval(Long menuId, String submittedBy) {
        Optional<ReconMenuMaster> opt = menuMasterRepository.findByMenuId(menuId);
        if (!opt.isPresent()) {
            return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Menu not found with ID: " + menuId, null), HttpStatus.NOT_FOUND);
        }
        ReconMenuMaster existing = opt.get();
        existing.setStatus("PENDING");
        existing.setSubmittedBy(submittedBy);
        existing.setModifiedBy(submittedBy);
        existing.setModifiedDate(new Timestamp(System.currentTimeMillis()));
        menuMasterRepository.save(existing);
        return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu submitted for approval.", null), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RestWithStatusList> approveMenu(Long menuId, String approvedBy) {
        Optional<ReconMenuMaster> opt = menuMasterRepository.findByMenuId(menuId);
        if (!opt.isPresent()) {
            return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Menu not found with ID: " + menuId, null), HttpStatus.NOT_FOUND);
        }
        ReconMenuMaster existing = opt.get();
        existing.setStatus("Y");
        existing.setApprovedBy(approvedBy);
        existing.setModifiedBy(approvedBy);
        existing.setModifiedDate(new Timestamp(System.currentTimeMillis()));
        menuMasterRepository.save(existing);
        if (existing.getSubmittedBy() != null) {
            Optional<ReconUser> maker = reconUserRepository.findByUsername(existing.getSubmittedBy());
            if (maker.isPresent()) {
                emailService.sendWorkflowDecisionNotification(
                        maker.get().getEmail(), maker.get().getFullName(),
                        "Menu", existing.getMenuName(), String.valueOf(existing.getMenuId()), "Approved", approvedBy);
            }
        }
        return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menu approved and activated.", null), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RestWithStatusList> getPendingMenusForChecker(String checkerUsername) {
        Optional<ReconUser> checkerOpt = reconUserRepository.findByUsername(checkerUsername);
        if (!checkerOpt.isPresent()) {
            return new ResponseEntity<>(new RestWithStatusList("FAILURE", "Checker not found: " + checkerUsername, null), HttpStatus.NOT_FOUND);
        }
        ReconUser checker = checkerOpt.get();
        List<ReconMenuMaster> visible = menuMasterRepository.findAll().stream()
                .filter(m -> "PENDING".equals(m.getStatus()))
                .filter(m -> isVisibleToChecker(checker, m.getCreatedBy(), m.getRoleId()))
                .collect(Collectors.toList());
        return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Pending menus fetched.", visible), HttpStatus.OK);
    }

    // Same scoping rule as ReconRoleMasterServiceImpl.isVisibleToChecker/getPendingRolesForChecker
    // — duplicated here rather than shared, since the two services live in different packages
    // (service vs service.v2) and this is a handful of lines, not worth a shared utility class for.
    private boolean isVisibleToChecker(ReconUser checker, String submitterUsername, Long itemRoleId) {
        if ("KAL_ADMIN".equals(checker.getUserType())) return true;

        Optional<ReconUser> submitterOpt = reconUserRepository.findByUsername(submitterUsername);
        if (!submitterOpt.isPresent() || !Objects.equals(submitterOpt.get().getBankId(), checker.getBankId())) {
            return false;
        }

        if (UserConstants.isAdminUserType(checker.getUserType())) return true;

        Set<Long> checkerScope = resolveProductScope(checker.getRoleId());
        Set<Long> itemScope = resolveProductScope(itemRoleId);
        return checkerScope.isEmpty() || itemScope.isEmpty() || !Collections.disjoint(checkerScope, itemScope);
    }

    private Set<Long> resolveProductScope(Long roleId) {
        if (roleId == null) return Collections.emptySet();
        return new HashSet<>(roleProductMapRepository.findProductIdsByRoleId(roleId));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getMenusByBankId(Long bankId) {
        List<ReconUser> bankUsers = reconUserRepository.findByBankId(bankId);

        List<Long> roleIdsFromUsers = bankUsers.stream()
                .map(ReconUser::getRoleId).filter(Objects::nonNull).distinct().collect(Collectors.toList());
        List<String> usernames = bankUsers.stream()
                .map(ReconUser::getUsername).filter(Objects::nonNull).distinct().collect(Collectors.toList());

        List<Long> roleIdsFromCreator = usernames.isEmpty() ? new ArrayList<>()
                : reconRoleMasterRepository.findByCreatedByIn(usernames).stream()
                        // A role an admin created can already be assigned to users of a DIFFERENT
                        // bank/branch (e.g. Bank Admin creates a role while onboarding a Branch).
                        // Such roles' menus belong to that branch's view, not this bank's.
                        .filter(r -> reconUserRepository.findByRoleId(r.getRoleId()).stream()
                                .allMatch(u -> bankId.equals(u.getBankId())))
                        .map(ReconRoleMaster::getRoleId).collect(Collectors.toList());

        List<Long> allRoleIds = new ArrayList<>(roleIdsFromUsers);
        roleIdsFromCreator.forEach(id -> { if (!allRoleIds.contains(id)) allRoleIds.add(id); });

        List<ReconMenuMaster> menus = allRoleIds.isEmpty() ? new ArrayList<>() : menuMasterRepository.findByRoleIdIn(allRoleIds);
        // /user-portal twins (see ReconRoleMasterServiceImpl.getOrCreateUserTwinMenu) are an
        // internal implementation detail resolved automatically at privilege-save time — never
        // something an Admin selects or manages directly, so hide them from this listing (used
        // by both the Menu Access Tree and Menu List) to avoid duplicate-looking rows.
        List<ReconMenuMaster> visible = menus.stream()
                .filter(m -> !"Y".equals(m.getIsPortalTwin()))
                .collect(Collectors.toList());
        return new ResponseEntity<>(new RestWithStatusList("SUCCESS", "Menus fetched for bank.", new ArrayList<>(visible)), HttpStatus.OK);
    }

    @Override
    public Long getVerifiedRoleId(String username) {
        Optional<ReconUser> userOpt = reconUserRepository.findByUsername(username);
        if (!userOpt.isPresent()) {
            throw new UsernameNotFoundException("User not found: " + username);
        }
        ReconUser reconUser = userOpt.get();
        if (reconUser.getRoleId() == null) {
            throw new UsernameNotFoundException("No role assigned to user: " + username);
        }
        return reconUser.getRoleId();
    }
}
