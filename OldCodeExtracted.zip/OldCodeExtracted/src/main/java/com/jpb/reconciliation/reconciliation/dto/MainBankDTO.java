package com.jpb.reconciliation.reconciliation.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class MainBankDTO {

    // ─── System Generated ────────────────────────────────────────────────────
    private Long bankId;
    private String bankCode; // 8 chars: first 4 letters + 4 digits (e.g. STAT4821)
    private String status;          // ACTIVE / INACTIVE / PENDING / BLOCKED / BLOCK_PENDING
    private LocalDateTime createdAt;
    private String createdBy;
    private Long parentBankId; // null = parent bank; non-null = sub-bnkitute
    private LocalDateTime inactivatedAt;     // when bank was last set INACTIVE (for 30s cooldown)
    private LocalDateTime blockScheduledAt;  // when block was scheduled (for countdown display)
    private LocalDateTime updatedAt;         // last audit timestamp
    private String updatedBy;               // who last modified
    private String blockScheduledBy;        // who scheduled the block
    private String blockReason;             // reason for block
    private String preBlockStatus;          // status before block was scheduled
    private String bankAdminId;             // bank admin username (e.g. areez.ansari)
    private Long adminId;                    // MainAdmin.id — used as originalEntityId in replacement
    private String adminStatus;             // status from Bank_Admin table (MainAdmin.status)
    private String replacementStatus;       // ACTIVE / PERMANENT / null — from ADMIN_REPLACEMENT table
    private String replacedByUsername;      // replacement admin's username
    private boolean replacementAdminRow;    // true = this row represents the replacement admin (not the original)

    // ─── Step 1: Bank Details ────────────────────────────────────────
    private String bankNameFull;   // required
    private String bankNameShort;  // optional
    private List<String> bankType;        // ["Issuer","Acquirer","Settlement Bank"]
    private String logoPath;              // set after logo upload

    // ─── Step 2: Registered Address ─────────────────────────────────────────
    private String regAddressLine1;   // required
    private String regAddressLine2;
    private String regAddressLine3;
    private String regCity;           // required
    private String regState;          // auto-populated
    private String regCountry;        // auto-populated
    private String regPhoneCode;      // e.g. +91
    private String regCityCode;       // e.g. 022
    private String regPhone;          // required

    // ─── Step 2: Communication Address ──────────────────────────────────────
    private Boolean sameAsRegistered; // if true, comm = reg
    private String commAddressLine1;
    private String commAddressLine2;
    private String commAddressLine3;
    private String commCity;
    private String commState;
    private String commCountry;
    private String commPhoneCode;
    private String commCityCode;
    private String commPhone;

    // ─── Step 3: Primary Contact ─────────────────────────────────────────────
    private String primaryFullName;       // required
    private String primaryEmail;          // required
    private String primaryMobileCode;     // e.g. +91
    private String primaryMobile;         // required, 10 digits
    private String primaryAltMobileCode;
    private String primaryAltMobile;

    // ─── Step 3: Secondary Contact ───────────────────────────────────────────
    private String secondaryFullName;
    private String secondaryEmail;
    private String secondaryMobileCode;
    private String secondaryMobile;
    private String secondaryAltMobileCode;
    private String secondaryAltMobile;

    // ─── Step 4: Products ────────────────────────────────────────────────────
    private List<String> selectedProducts;
    // { "UPI": { "validFrom": "2024-01-01", "validTo": "2024-12-31" }, ... }
    private Map<String, ProductDateEntry> productDates;

    public static class ProductDateEntry {
        private LocalDate validFrom;
        private LocalDate validTo;
        public LocalDate getValidFrom() { return validFrom; }
        public void setValidFrom(LocalDate validFrom) { this.validFrom = validFrom; }
        public LocalDate getValidTo() { return validTo; }
        public void setValidTo(LocalDate validTo) { this.validTo = validTo; }
    }

    // ─── Step 5: Security ────────────────────────────────────────────────────
    private Boolean enableMfa;
    private Boolean enableHrms;
    private Boolean enableOtp;

    // ─── Super-User Credentials (returned on create, shown on success page) ──
    private String superUserId;
    private String defaultPassword;

    // ─── Getters & Setters ───────────────────────────────────────────────────

    public Long getBankId() { return bankId; }
    public void setBankId(Long bankId) { this.bankId = bankId; }

    public Long getParentBankId() { return parentBankId; }
    public void setParentBankId(Long parentBankId) { this.parentBankId = parentBankId; }

    public String getBankCode() { return bankCode; }
    public void setBankCode(String bankCode) { this.bankCode = bankCode; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getInactivatedAt() { return inactivatedAt; }
    public void setInactivatedAt(LocalDateTime inactivatedAt) { this.inactivatedAt = inactivatedAt; }

    public LocalDateTime getBlockScheduledAt() { return blockScheduledAt; }
    public void setBlockScheduledAt(LocalDateTime blockScheduledAt) { this.blockScheduledAt = blockScheduledAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public String getUpdatedBy() { return updatedBy; }
    public void setUpdatedBy(String updatedBy) { this.updatedBy = updatedBy; }

    public String getBlockScheduledBy() { return blockScheduledBy; }
    public void setBlockScheduledBy(String blockScheduledBy) { this.blockScheduledBy = blockScheduledBy; }

    public String getBlockReason() { return blockReason; }
    public void setBlockReason(String blockReason) { this.blockReason = blockReason; }

    public String getPreBlockStatus() { return preBlockStatus; }
    public void setPreBlockStatus(String preBlockStatus) { this.preBlockStatus = preBlockStatus; }

    public String getBankAdminId() { return bankAdminId; }
    public void setBankAdminId(String bankAdminId) { this.bankAdminId = bankAdminId; }

    public Long getAdminId() { return adminId; }
    public void setAdminId(Long adminId) { this.adminId = adminId; }

    public String getAdminStatus() { return adminStatus; }
    public void setAdminStatus(String adminStatus) { this.adminStatus = adminStatus; }

    public String getReplacementStatus() { return replacementStatus; }
    public void setReplacementStatus(String replacementStatus) { this.replacementStatus = replacementStatus; }

    public String getReplacedByUsername() { return replacedByUsername; }
    public void setReplacedByUsername(String replacedByUsername) { this.replacedByUsername = replacedByUsername; }

    public boolean isReplacementAdminRow() { return replacementAdminRow; }
    public void setReplacementAdminRow(boolean replacementAdminRow) { this.replacementAdminRow = replacementAdminRow; }

    public String getBankNameFull() { return bankNameFull; }
    public void setBankNameFull(String bankNameFull) { this.bankNameFull = bankNameFull; }

    public String getBankNameShort() { return bankNameShort; }
    public void setBankNameShort(String bankNameShort) { this.bankNameShort = bankNameShort; }

    public List<String> getBankType() { return bankType; }
    public void setBankType(List<String> bankType) { this.bankType = bankType; }

    public String getLogoPath() { return logoPath; }
    public void setLogoPath(String logoPath) { this.logoPath = logoPath; }

    public String getRegAddressLine1() { return regAddressLine1; }
    public void setRegAddressLine1(String regAddressLine1) { this.regAddressLine1 = regAddressLine1; }

    public String getRegAddressLine2() { return regAddressLine2; }
    public void setRegAddressLine2(String regAddressLine2) { this.regAddressLine2 = regAddressLine2; }

    public String getRegAddressLine3() { return regAddressLine3; }
    public void setRegAddressLine3(String regAddressLine3) { this.regAddressLine3 = regAddressLine3; }

    public String getRegCity() { return regCity; }
    public void setRegCity(String regCity) { this.regCity = regCity; }

    public String getRegState() { return regState; }
    public void setRegState(String regState) { this.regState = regState; }

    public String getRegCountry() { return regCountry; }
    public void setRegCountry(String regCountry) { this.regCountry = regCountry; }

    public String getRegPhoneCode() { return regPhoneCode; }
    public void setRegPhoneCode(String regPhoneCode) { this.regPhoneCode = regPhoneCode; }

    public String getRegCityCode() { return regCityCode; }
    public void setRegCityCode(String regCityCode) { this.regCityCode = regCityCode; }

    public String getRegPhone() { return regPhone; }
    public void setRegPhone(String regPhone) { this.regPhone = regPhone; }

    public Boolean getSameAsRegistered() { return sameAsRegistered; }
    public void setSameAsRegistered(Boolean sameAsRegistered) { this.sameAsRegistered = sameAsRegistered; }

    public String getCommAddressLine1() { return commAddressLine1; }
    public void setCommAddressLine1(String commAddressLine1) { this.commAddressLine1 = commAddressLine1; }

    public String getCommAddressLine2() { return commAddressLine2; }
    public void setCommAddressLine2(String commAddressLine2) { this.commAddressLine2 = commAddressLine2; }

    public String getCommAddressLine3() { return commAddressLine3; }
    public void setCommAddressLine3(String commAddressLine3) { this.commAddressLine3 = commAddressLine3; }

    public String getCommCity() { return commCity; }
    public void setCommCity(String commCity) { this.commCity = commCity; }

    public String getCommState() { return commState; }
    public void setCommState(String commState) { this.commState = commState; }

    public String getCommCountry() { return commCountry; }
    public void setCommCountry(String commCountry) { this.commCountry = commCountry; }

    public String getCommPhoneCode() { return commPhoneCode; }
    public void setCommPhoneCode(String commPhoneCode) { this.commPhoneCode = commPhoneCode; }

    public String getCommCityCode() { return commCityCode; }
    public void setCommCityCode(String commCityCode) { this.commCityCode = commCityCode; }

    public String getCommPhone() { return commPhone; }
    public void setCommPhone(String commPhone) { this.commPhone = commPhone; }

    public String getPrimaryFullName() { return primaryFullName; }
    public void setPrimaryFullName(String primaryFullName) { this.primaryFullName = primaryFullName; }

    public String getPrimaryEmail() { return primaryEmail; }
    public void setPrimaryEmail(String primaryEmail) { this.primaryEmail = primaryEmail; }

    public String getPrimaryMobileCode() { return primaryMobileCode; }
    public void setPrimaryMobileCode(String primaryMobileCode) { this.primaryMobileCode = primaryMobileCode; }

    public String getPrimaryMobile() { return primaryMobile; }
    public void setPrimaryMobile(String primaryMobile) { this.primaryMobile = primaryMobile; }

    public String getPrimaryAltMobileCode() { return primaryAltMobileCode; }
    public void setPrimaryAltMobileCode(String primaryAltMobileCode) { this.primaryAltMobileCode = primaryAltMobileCode; }

    public String getPrimaryAltMobile() { return primaryAltMobile; }
    public void setPrimaryAltMobile(String primaryAltMobile) { this.primaryAltMobile = primaryAltMobile; }

    public String getSecondaryFullName() { return secondaryFullName; }
    public void setSecondaryFullName(String secondaryFullName) { this.secondaryFullName = secondaryFullName; }

    public String getSecondaryEmail() { return secondaryEmail; }
    public void setSecondaryEmail(String secondaryEmail) { this.secondaryEmail = secondaryEmail; }

    public String getSecondaryMobileCode() { return secondaryMobileCode; }
    public void setSecondaryMobileCode(String secondaryMobileCode) { this.secondaryMobileCode = secondaryMobileCode; }

    public String getSecondaryMobile() { return secondaryMobile; }
    public void setSecondaryMobile(String secondaryMobile) { this.secondaryMobile = secondaryMobile; }

    public String getSecondaryAltMobileCode() { return secondaryAltMobileCode; }
    public void setSecondaryAltMobileCode(String secondaryAltMobileCode) { this.secondaryAltMobileCode = secondaryAltMobileCode; }

    public String getSecondaryAltMobile() { return secondaryAltMobile; }
    public void setSecondaryAltMobile(String secondaryAltMobile) { this.secondaryAltMobile = secondaryAltMobile; }

    public List<String> getSelectedProducts() { return selectedProducts; }
    public void setSelectedProducts(List<String> selectedProducts) { this.selectedProducts = selectedProducts; }

    public Map<String, ProductDateEntry> getProductDates() { return productDates; }
    public void setProductDates(Map<String, ProductDateEntry> productDates) { this.productDates = productDates; }

    public Boolean getEnableMfa() { return enableMfa; }
    public void setEnableMfa(Boolean enableMfa) { this.enableMfa = enableMfa; }

    public Boolean getEnableHrms() { return enableHrms; }
    public void setEnableHrms(Boolean enableHrms) { this.enableHrms = enableHrms; }

    public Boolean getEnableOtp() { return enableOtp; }
    public void setEnableOtp(Boolean enableOtp) { this.enableOtp = enableOtp; }

    public String getSuperUserId() { return superUserId; }
    public void setSuperUserId(String superUserId) { this.superUserId = superUserId; }

    public String getDefaultPassword() { return defaultPassword; }
    public void setDefaultPassword(String defaultPassword) { this.defaultPassword = defaultPassword; }
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
}
