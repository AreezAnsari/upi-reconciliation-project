package com.jpb.reconciliation.reconciliation.dto;

import javax.validation.constraints.*;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AddUserRequest {

    @NotBlank(message = "Full name is required")
    @Size(min = 2, max = 200, message = "Full name must be between 2 and 200 characters")
    private String fullName;

    @NotBlank(message = "Username is required")
    @Size(min = 2, max = 100, message = "Username must be between 2 and 100 characters")
    @Pattern(
            regexp = "^[A-Za-z][a-zA-Z]*(\\.[A-Za-z][a-zA-Z]*)?$",
            message = "Username must be alphabetic, optionally in First.Last format (e.g. Karan or Karan.Joshi)"
    )
    private String username;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email address")
    private String email;

    private String department;

    private String designation;

    @Pattern(regexp = "^[6-9][0-9]{9}$", message = "Mobile number must be a valid 10-digit Indian number starting with 6-9")
    private String mobileNumber;

    @NotBlank(message = "Role is required")
    @Pattern(regexp = "MAKER|CHECKER|WORKER|AUDITOR|IT_OPS|SUPERVISOR|RCC_CXO|DEFAULT", message = "Invalid role value")
    private String role;

    @Pattern(regexp = "INTERNAL|EXTERNAL", message = "User type must be INTERNAL or EXTERNAL")
    @Builder.Default
    private String userType = "INTERNAL";

    private String externalDepartmentName;
    private String externalSupervisorName;
    private String externalSupervisorEmail;
    private String externalSupervisorPhone;
}
