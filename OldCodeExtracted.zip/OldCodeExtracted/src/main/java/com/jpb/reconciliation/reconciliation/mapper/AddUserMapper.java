package com.jpb.reconciliation.reconciliation.mapper;

import com.jpb.reconciliation.reconciliation.dto.AddUserRequest;
import com.jpb.reconciliation.reconciliation.dto.AddUserResponse;
import com.jpb.reconciliation.reconciliation.entity.AddUser;

public class AddUserMapper {

    public static AddUser toEntity(AddUserRequest req, String createdBy, String bankCode,
                                   String branchCode, String defaultPassword) {

        boolean isExternal = "EXTERNAL".equalsIgnoreCase(req.getUserType());

        return AddUser.builder()
                .fullName(req.getFullName())
                .username(req.getUsername().trim().toLowerCase())
                .email(req.getEmail())
                .department(req.getDepartment())
                .designation(req.getDesignation())
                .mobileNumber(req.getMobileNumber())
                .userType(AddUser.UserType.valueOf(req.getUserType().toUpperCase()))
                .role(AddUser.Role.valueOf(req.getRole().toUpperCase()))
                .passwordSet(0)
                .status(AddUser.UserStatus.REQUEST)
                .createdBy(createdBy)
                .bankCode(bankCode)
                .branchCode(branchCode)
                .defaultPassword(defaultPassword) // BCrypt hash, same as MainBank pattern
                .externalDepartmentName(isExternal ? req.getExternalDepartmentName() : null)
                .externalSupervisorName(isExternal ? req.getExternalSupervisorName() : null)
                .externalSupervisorEmail(isExternal ? req.getExternalSupervisorEmail() : null)
                .externalSupervisorPhone(isExternal ? req.getExternalSupervisorPhone() : null)
                .build();
    }

    public static AddUserResponse toResponse(AddUser user) {

        return AddUserResponse.builder()
                .id(user.getId())
                .fullName(user.getFullName())
                .username(user.getUsername())
                .email(user.getEmail())
                .department(user.getDepartment())
                .designation(user.getDesignation())
                .mobileNumber(user.getMobileNumber())
                .userType(user.getUserType() != null ? user.getUserType().name() : null)
                .role(user.getRole() != null ? user.getRole().name() : null)
                .status(user.getStatus() != null ? user.getStatus().name() : null)
                .externalDepartmentName(user.getExternalDepartmentName())
                .externalSupervisorName(user.getExternalSupervisorName())
                .externalSupervisorEmail(user.getExternalSupervisorEmail())
                .externalSupervisorPhone(user.getExternalSupervisorPhone())
                .bankCode(user.getBankCode())
                .branchCode(user.getBranchCode())
                .createdBy(user.getCreatedBy())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .inactivateScheduledAt(user.getInactivateScheduledAt())
                .blockScheduledAt(user.getBlockScheduledAt())
                .reactivateScheduledAt(user.getReactivateScheduledAt())
                .parentId(user.getParentId())
                .replacementAdminRow(user.getEmail() != null && user.getEmail().toLowerCase().startsWith("(replace)"))
                .build();
    }
}
