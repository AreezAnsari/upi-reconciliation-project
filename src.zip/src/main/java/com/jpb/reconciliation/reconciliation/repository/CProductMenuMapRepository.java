package com.jpb.reconciliation.reconciliation.repository;

import com.jpb.reconciliation.reconciliation.entity.CProductMenuMap;
import com.jpb.reconciliation.reconciliation.entity.CProductMenuMap.ProductMenuMapId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CProductMenuMapRepository extends JpaRepository<CProductMenuMap, ProductMenuMapId> {

    List<CProductMenuMap> findByIdProductId(Long productId);

    List<CProductMenuMap> findByIdMenuId(Long menuId);

    void deleteByIdProductId(Long productId);

    void deleteByIdMenuId(Long menuId);
}
