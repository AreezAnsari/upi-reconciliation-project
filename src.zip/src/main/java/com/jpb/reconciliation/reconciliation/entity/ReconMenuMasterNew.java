package com.jpb.reconciliation.reconciliation.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "RECON_MENU_MASTER")
public class ReconMenuMasterNew {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MENU_ID")
    private Long menuId;

    @Column(name = "MENU_NAME", length = 200, nullable = false)
    private String menuName;

    @Column(name = "PARENT_MENU_ID")
    private Long parentMenuId;

    @Column(name = "MENU_TYPE", length = 20, nullable = false)
    private String menuType;

    @Column(name = "DESCRIPTION", length = 500)
    private String description;

    @Column(name = "STATUS", length = 20, nullable = false)
    private String status = "ACTIVE";
}
