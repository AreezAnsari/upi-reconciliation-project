package com.jpb.reconciliation.reconciliation.service;

import com.jpb.reconciliation.reconciliation.dto.RestWithStatusList;
import com.jpb.reconciliation.reconciliation.entity.ReconBankMaster;
import com.jpb.reconciliation.reconciliation.repository.ReconBankMasterRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class ReconBankMasterServiceImpl implements ReconBankMasterService {

    private static final Logger logger = LoggerFactory.getLogger(ReconBankMasterServiceImpl.class);

    @Autowired
    private ReconBankMasterRepository reconBankMasterRepository;

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> createBank(ReconBankMaster bank, String createdBy) {
        if (bank.getBankCode() == null || bank.getBankCode().trim().isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "Bank code is required.", null));
        }
        if (reconBankMasterRepository.existsByBankCode(bank.getBankCode().trim().toUpperCase())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(new RestWithStatusList("FAILURE", "Bank code already exists.", null));
        }
        if (reconBankMasterRepository.existsByBankName(bank.getBankName())) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(new RestWithStatusList("FAILURE", "Bank name already exists.", null));
        }
        bank.setBankCode(bank.getBankCode().trim().toUpperCase());
        bank.setCreatedAt(LocalDateTime.now());
        bank.setCreatedBy(createdBy);
        if (bank.getStatus() == null) {
            bank.setStatus("ACTIVE");
        }
        ReconBankMaster saved = reconBankMasterRepository.save(bank);
        logger.info("ReconBankMaster created: {} by {}", saved.getBankCode(), createdBy);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new RestWithStatusList("SUCCESS", "Bank created successfully.", Collections.singletonList(saved)));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getAllBanks() {
        List<ReconBankMaster> banks = reconBankMasterRepository.findAll();
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Banks fetched.", banks));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getBankById(Long bankId) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank found.", Collections.singletonList(opt.get())));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getBankByCode(String bankCode) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findByBankCode(bankCode);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with code: " + bankCode, null));
        }
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank found.", Collections.singletonList(opt.get())));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getBanksByStatus(String status) {
        List<ReconBankMaster> banks = reconBankMasterRepository.findByStatus(status);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Banks fetched by status.", banks));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getBanksByType(String bankType) {
        List<ReconBankMaster> banks = reconBankMasterRepository.findByBankType(bankType);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Banks fetched by type.", banks));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getBranchBanks(Long parentBankId) {
        List<ReconBankMaster> banks = reconBankMasterRepository.findByParentBankId(parentBankId);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Branch banks fetched.", banks));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> updateBank(Long bankId, ReconBankMaster bank, String updatedBy) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        ReconBankMaster existing = opt.get();
        if (bank.getBankName() != null) existing.setBankName(bank.getBankName());
        if (bank.getBankCategory() != null) existing.setBankCategory(bank.getBankCategory());
        if (bank.getRegAddress() != null) existing.setRegAddress(bank.getRegAddress());
        if (bank.getRegCity() != null) existing.setRegCity(bank.getRegCity());
        if (bank.getRegState() != null) existing.setRegState(bank.getRegState());
        if (bank.getRegCountry() != null) existing.setRegCountry(bank.getRegCountry());
        if (bank.getRegPhone() != null) existing.setRegPhone(bank.getRegPhone());
        existing.setUpdatedAt(LocalDateTime.now());
        existing.setUpdatedBy(updatedBy);
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster updated: {} by {}", bankId, updatedBy);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank updated successfully.", Collections.singletonList(existing)));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> updateStatus(Long bankId, String status, String updatedBy) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        ReconBankMaster existing = opt.get();
        existing.setStatus(status);
        existing.setUpdatedAt(LocalDateTime.now());
        existing.setUpdatedBy(updatedBy);
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster status updated to {} for ID: {} by {}", status, bankId, updatedBy);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank status updated.", null));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> deleteBank(Long bankId) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        ReconBankMaster existing = opt.get();
        existing.setStatus("INACTIVE");
        existing.setUpdatedAt(LocalDateTime.now());
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster soft-deleted (INACTIVE): {}", bankId);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank deactivated successfully.", null));
    }

    @Override
    public ResponseEntity<RestWithStatusList> checkBankCodeExists(String bankCode) {
        boolean exists = reconBankMasterRepository.existsByBankCode(bankCode);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", exists ? "EXISTS" : "AVAILABLE", null));
    }

    @Override
    public ResponseEntity<RestWithStatusList> checkBankNameExists(String bankName) {
        boolean exists = reconBankMasterRepository.existsByBankName(bankName);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", exists ? "EXISTS" : "AVAILABLE", null));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> blockBank(Long bankId, String reason, String updatedBy) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        ReconBankMaster existing = opt.get();
        if ("BLOCKED".equals(existing.getStatus())) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "Bank is already BLOCKED.", null));
        }
        existing.setPreBlockStatus(existing.getStatus());
        existing.setStatus("BLOCKED");
        existing.setBlockReason(reason);
        existing.setUpdatedAt(LocalDateTime.now());
        existing.setUpdatedBy(updatedBy);
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster BLOCKED: bankId={} preBlockStatus={} by {}", bankId, existing.getPreBlockStatus(), updatedBy);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank blocked successfully.", null));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> unblockBank(Long bankId, String updatedBy) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        ReconBankMaster existing = opt.get();
        if (!"BLOCKED".equals(existing.getStatus())) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "Bank is not currently BLOCKED.", null));
        }
        String restoreStatus = existing.getPreBlockStatus() != null ? existing.getPreBlockStatus() : "ACTIVE";
        existing.setStatus(restoreStatus);
        existing.setPreBlockStatus(null);
        existing.setBlockReason(null);
        existing.setUpdatedAt(LocalDateTime.now());
        existing.setUpdatedBy(updatedBy);
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster UNBLOCKED: bankId={} restored to {} by {}", bankId, restoreStatus, updatedBy);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank unblocked. Status restored to: " + restoreStatus, null));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> scheduleInactivate(Long bankId, LocalDateTime scheduledAt, String scheduledBy) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        if (scheduledAt == null || scheduledAt.isBefore(LocalDateTime.now())) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "Scheduled time must be in the future.", null));
        }
        ReconBankMaster existing = opt.get();
        existing.setInactivateScheduledAt(scheduledAt);
        existing.setInactivateScheduledBy(scheduledBy);
        existing.setUpdatedAt(LocalDateTime.now());
        existing.setUpdatedBy(scheduledBy);
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster INACTIVATE scheduled at {} for bankId={} by {}", scheduledAt, bankId, scheduledBy);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank inactivation scheduled at: " + scheduledAt, null));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> scheduleReactivate(Long bankId, LocalDateTime scheduledAt, String scheduledBy) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        if (scheduledAt == null || scheduledAt.isBefore(LocalDateTime.now())) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "Scheduled time must be in the future.", null));
        }
        ReconBankMaster existing = opt.get();
        existing.setReactivateScheduledAt(scheduledAt);
        existing.setReactivateScheduledBy(scheduledBy);
        existing.setUpdatedAt(LocalDateTime.now());
        existing.setUpdatedBy(scheduledBy);
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster REACTIVATE scheduled at {} for bankId={} by {}", scheduledAt, bankId, scheduledBy);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank reactivation scheduled at: " + scheduledAt, null));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> scheduleBlock(Long bankId, LocalDateTime scheduledAt, String scheduledBy, String reason) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        if (scheduledAt == null || scheduledAt.isBefore(LocalDateTime.now())) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "Scheduled time must be in the future.", null));
        }
        ReconBankMaster existing = opt.get();
        existing.setBlockScheduledAt(scheduledAt);
        existing.setBlockScheduledBy(scheduledBy);
        existing.setBlockReason(reason);
        existing.setUpdatedAt(LocalDateTime.now());
        existing.setUpdatedBy(scheduledBy);
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster BLOCK scheduled at {} for bankId={} by {}", scheduledAt, bankId, scheduledBy);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Bank block scheduled at: " + scheduledAt, null));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> cancelSchedule(Long bankId, String scheduleType, String updatedBy) {
        Optional<ReconBankMaster> opt = reconBankMasterRepository.findById(bankId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Bank not found with ID: " + bankId, null));
        }
        ReconBankMaster existing = opt.get();
        if (scheduleType == null) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "scheduleType is required (INACTIVATE / REACTIVATE / BLOCK).", null));
        }
        switch (scheduleType.toUpperCase()) {
            case "INACTIVATE":
                existing.setInactivateScheduledAt(null);
                existing.setInactivateScheduledBy(null);
                break;
            case "REACTIVATE":
                existing.setReactivateScheduledAt(null);
                existing.setReactivateScheduledBy(null);
                break;
            case "BLOCK":
                existing.setBlockScheduledAt(null);
                existing.setBlockScheduledBy(null);
                break;
            default:
                return ResponseEntity.badRequest()
                        .body(new RestWithStatusList("FAILURE", "Invalid scheduleType. Use INACTIVATE, REACTIVATE, or BLOCK.", null));
        }
        existing.setUpdatedAt(LocalDateTime.now());
        existing.setUpdatedBy(updatedBy);
        reconBankMasterRepository.save(existing);
        logger.info("ReconBankMaster {} schedule cancelled for bankId={} by {}", scheduleType, bankId, updatedBy);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", scheduleType + " schedule cancelled.", null));
    }
}



