package com.jpb.reconciliation.reconciliation.service;

import com.jpb.reconciliation.reconciliation.constants.CommonConstants;
import com.jpb.reconciliation.reconciliation.dto.RestWithStatusList;
import com.jpb.reconciliation.reconciliation.dto.UpiAdjSummaryDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.*;

@Slf4j
@Service
public class UpiAdjSummaryServiceImpl implements UpiAdjSummaryService {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public UpiAdjSummaryServiceImpl(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    // ── ADJTYPE → Category mapping ─────────────────────────────────
    private static final Map<String, String> CATEGORY_MAP = new LinkedHashMap<>();
    static {
        CATEGORY_MAP.put("Online Refund",                  "Refund");
        CATEGORY_MAP.put("Refund Reversal Confirmation",   "Refund");
        CATEGORY_MAP.put("RET",                            "Refund");
        CATEGORY_MAP.put("Fraud Chargeback Raise",         "Chargeback");
        CATEGORY_MAP.put("Fraud Chargeback Representment", "Chargeback");
        CATEGORY_MAP.put("Chargeback Raise",               "Chargeback");
        CATEGORY_MAP.put("Chargeback Acceptance",          "Chargeback");
        CATEGORY_MAP.put("TCC",                            "True Credit/Debit");
        CATEGORY_MAP.put("Debit Reversal Confirmation",    "True Credit/Debit");
        CATEGORY_MAP.put("Re-presentment Raise",           "Re-presentment");
        CATEGORY_MAP.put("Wrong Credit Chargeback Raise",  "Re-presentment");
        CATEGORY_MAP.put("Wrong credit Representment",     "Re-presentment");
        CATEGORY_MAP.put("Differed Re-presentment Raise",  "Re-presentment");
        CATEGORY_MAP.put("Credit Adjustment",              "GL Adjustment");
        CATEGORY_MAP.put("Response to Complaint",          "GL Adjustment");
        CATEGORY_MAP.put("Complaint Raise",                "GL Adjustment");
        CATEGORY_MAP.put("Pre-Arbitration Raise",          "GL Adjustment");
    }

    // ── ADJTYPE → Flag mapping ─────────────────────────────────────
    private static final Map<String, String> FLAG_MAP = new LinkedHashMap<>();
    static {
        FLAG_MAP.put("Online Refund",                  "REF");
        FLAG_MAP.put("Refund Reversal Confirmation",   "RRC");
        FLAG_MAP.put("RET",                            "RET");
        FLAG_MAP.put("Fraud Chargeback Raise",         "FC");
        FLAG_MAP.put("Fraud Chargeback Representment", "FCR");
        FLAG_MAP.put("Chargeback Raise",               "CB");
        FLAG_MAP.put("Chargeback Acceptance",          "CBA");
        FLAG_MAP.put("TCC",                            "TCC");
        FLAG_MAP.put("Debit Reversal Confirmation",    "DRC");
        FLAG_MAP.put("Re-presentment Raise",           "R");
        FLAG_MAP.put("Wrong Credit Chargeback Raise",  "WR");
        FLAG_MAP.put("Wrong credit Representment",     "WCR");
        FLAG_MAP.put("Differed Re-presentment Raise",  "DRP");
        FLAG_MAP.put("Credit Adjustment",              "C");
        FLAG_MAP.put("Response to Complaint",          "RC");
        FLAG_MAP.put("Complaint Raise",                "CL");
        FLAG_MAP.put("Pre-Arbitration Raise",          "PA");
    }

    // ── RESPONSE code → TTUM Status ───────────────────────────────
    private static final Map<String, String> TTUM_MAP = new LinkedHashMap<>();
    static {
        TTUM_MAP.put("00", "Generated");
        TTUM_MAP.put("RB", "Pending");
        TTUM_MAP.put("R9", "Pending");
        TTUM_MAP.put("RR", "Approved");
        TTUM_MAP.put("U9", "Not Gen.");
        TTUM_MAP.put("UR", "Not Gen.");
    }

    // ── Category display order ─────────────────────────────────────
    private static final List<String> CATEGORY_ORDER =
            Arrays.asList("Refund", "Chargeback", "True Credit/Debit", "Re-presentment", "GL Adjustment");

    // ── Oracle SQL — GROUP BY ADJTYPE on REC_UPI_ADJ_DATA ─────────
    private static final String SQL =
            "SELECT ADJTYPE, " +
            "       COUNT(*)        AS CNT, " +
            "       SUM(TRAN_AMOUNT) AS TOTAL_AMT, " +
            "       MAX(RESPONSE)   AS RESPONSE " +
            "FROM   REC_UPI_ADJ_DATA " +
            "GROUP  BY ADJTYPE " +
            "ORDER  BY ADJTYPE";

    // ── Main service method ────────────────────────────────────────
    @Override
    public ResponseEntity<RestWithStatusList> getAdjSummaryByType() {
        try {
            log.info("Fetching UPI Adj Summary — GROUP BY ADJTYPE from REC_UPI_ADJ_DATA");

            // Step 1: DB se data fetch karo
            List<Map<String, Object>> dbRows = jdbcTemplate.queryForList(SQL);
            log.info("DB rows fetched: {}", dbRows.size());

            // Step 2: category wise items collect karo
            Map<String, List<UpiAdjSummaryDto>> itemsMap   = new LinkedHashMap<>();
            Map<String, Integer>                countMap   = new LinkedHashMap<>();
            Map<String, Double>                 amountMap  = new LinkedHashMap<>();

            for (Map<String, Object> row : dbRows) {

                String adjtype  = row.get("ADJTYPE")   != null ? row.get("ADJTYPE").toString().trim()            : "";
                int    cnt      = row.get("CNT")        != null ? ((Number) row.get("CNT")).intValue()            : 0;
                double amt      = row.get("TOTAL_AMT")  != null ? ((Number) row.get("TOTAL_AMT")).doubleValue()   : 0.0;
                String response = row.get("RESPONSE")   != null ? row.get("RESPONSE").toString().trim()           : "";

                if (!CATEGORY_MAP.containsKey(adjtype)) {
                    log.warn("Unknown ADJTYPE — skipped: {}", adjtype);
                    continue;
                }

                String category  = CATEGORY_MAP.get(adjtype);
                String flag      = FLAG_MAP.getOrDefault(adjtype, "??");
                String ttumStatus = TTUM_MAP.getOrDefault(response, "Unknown");

                // Build item DTO
                UpiAdjSummaryDto item = new UpiAdjSummaryDto();
                item.setCategory(category);
                item.setFlag(flag);
                item.setAdjustmentType(adjtype);
                item.setCount(cnt);
                item.setAmount(Math.round(amt * 100.0) / 100.0);
                item.setTtumStatus(ttumStatus);

                itemsMap.computeIfAbsent(category, k -> new ArrayList<>()).add(item);
                countMap.merge(category,  cnt, Integer::sum);
                amountMap.merge(category, amt, Double::sum);
            }

            // Step 3: Final response list banao — category order ke hisab se
            List<Object> responseList = new ArrayList<>();
            int    grandTotalRecords = 0;
            double grandTotalAmount  = 0.0;

            for (String cat : CATEGORY_ORDER) {
                if (!itemsMap.containsKey(cat)) continue;

                int    totalRec = countMap.getOrDefault(cat, 0);
                double totalAmt = amountMap.getOrDefault(cat, 0.0);

                // Category header DTO
                Map<String, Object> group = new LinkedHashMap<>();
                group.put("category",     cat);
                group.put("totalRecords", totalRec);
                group.put("totalAmount",  Math.round(totalAmt * 100.0) / 100.0);
                group.put("items",        itemsMap.get(cat));

                responseList.add(group);

                grandTotalRecords += totalRec;
                grandTotalAmount  += totalAmt;
            }

            // Grand total
            Map<String, Object> grandTotal = new LinkedHashMap<>();
            grandTotal.put("grandTotalRecords", grandTotalRecords);
            grandTotal.put("grandTotalAmount",  Math.round(grandTotalAmount * 100.0) / 100.0);
            responseList.add(grandTotal);

            log.info("Adj Summary built — groups: {}, grandTotal: {}", responseList.size() - 1, grandTotalRecords);

            RestWithStatusList response = RestWithStatusList.builder()
                    .status(CommonConstants.SUCCESS)
                    .statusMsg("Request executed successfully")
                    .data(responseList)
                    .build();

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Error in getAdjSummaryByType: {}", e.getMessage());
            RestWithStatusList errorResponse = RestWithStatusList.builder()
                    .status(CommonConstants.FAILURE)
                    .statusMsg("Error: " + e.getMessage())
                    .data(Collections.emptyList())
                    .build();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
}