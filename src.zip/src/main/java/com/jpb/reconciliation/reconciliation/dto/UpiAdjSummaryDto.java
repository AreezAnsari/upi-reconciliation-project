package com.jpb.reconciliation.reconciliation.dto;

import lombok.Data;

@Data
public class UpiAdjSummaryDto {

    // Category group fields
    private String category;       // Refund, Chargeback, True Credit/Debit, Re-presentment, GL Adjustment
    private int    totalRecords;   // Total count for this category
    private double totalAmount;    // Total amount for this category

    // Sub-row fields (each adjtype row under category)
    private String flag;           // REF, RRC, FC, TCC, DRC, C etc.
    private String adjustmentType; // Online Refund, TCC, Credit Adjustment etc.
    private int    count;          // COUNT(*) GROUP BY ADJTYPE
    private double amount;         // SUM(TXNAMOUNT) GROUP BY ADJTYPE
    private String ttumStatus;     // Generated, Pending, Approved, Not Gen.
}