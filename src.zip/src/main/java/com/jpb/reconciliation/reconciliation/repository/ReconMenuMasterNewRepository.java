package com.jpb.reconciliation.reconciliation.repository;

import com.jpb.reconciliation.reconciliation.entity.ReconMenuMasterNew;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReconMenuMasterNewRepository extends JpaRepository<ReconMenuMasterNew, Long> {

    List<ReconMenuMasterNew> findByStatus(String status);

    List<ReconMenuMasterNew> findByMenuType(String menuType);

    List<ReconMenuMasterNew> findByParentMenuId(Long parentMenuId);

    boolean existsByMenuName(String menuName);
}
