package com.jpb.reconciliation.reconciliation.service;

import com.jpb.reconciliation.reconciliation.dto.RestWithStatusList;
import com.jpb.reconciliation.reconciliation.entity.ReconMenuMasterNew;
import com.jpb.reconciliation.reconciliation.repository.ReconMenuMasterNewRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class ReconMenuMasterNewServiceImpl implements ReconMenuMasterNewService {

    private static final Logger logger = LoggerFactory.getLogger(ReconMenuMasterNewServiceImpl.class);

    @Autowired
    private ReconMenuMasterNewRepository reconMenuMasterNewRepository;

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> createMenu(ReconMenuMasterNew menu) {
        if (menu.getMenuName() == null || menu.getMenuName().trim().isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "Menu name is required.", null));
        }
        if (menu.getMenuType() == null || menu.getMenuType().trim().isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new RestWithStatusList("FAILURE", "Menu type is required.", null));
        }
        if (menu.getStatus() == null) {
            menu.setStatus("ACTIVE");
        }
        ReconMenuMasterNew saved = reconMenuMasterNewRepository.save(menu);
        logger.info("ReconMenuMasterNew created: {}", saved.getMenuId());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new RestWithStatusList("SUCCESS", "Menu created successfully.", Collections.singletonList(saved)));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getAllMenus() {
        List<ReconMenuMasterNew> menus = reconMenuMasterNewRepository.findAll();
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Menus fetched.", menus));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getMenuById(Long menuId) {
        Optional<ReconMenuMasterNew> opt = reconMenuMasterNewRepository.findById(menuId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Menu not found with ID: " + menuId, null));
        }
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Menu found.", Collections.singletonList(opt.get())));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getMenusByStatus(String status) {
        List<ReconMenuMasterNew> menus = reconMenuMasterNewRepository.findByStatus(status);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Menus fetched by status.", menus));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getMenusByType(String menuType) {
        List<ReconMenuMasterNew> menus = reconMenuMasterNewRepository.findByMenuType(menuType);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Menus fetched by type.", menus));
    }

    @Override
    public ResponseEntity<RestWithStatusList> getChildMenus(Long parentMenuId) {
        List<ReconMenuMasterNew> menus = reconMenuMasterNewRepository.findByParentMenuId(parentMenuId);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Child menus fetched.", menus));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> updateMenu(Long menuId, ReconMenuMasterNew menu) {
        Optional<ReconMenuMasterNew> opt = reconMenuMasterNewRepository.findById(menuId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Menu not found with ID: " + menuId, null));
        }
        ReconMenuMasterNew existing = opt.get();
        if (menu.getMenuName() != null) existing.setMenuName(menu.getMenuName());
        if (menu.getMenuType() != null) existing.setMenuType(menu.getMenuType());
        if (menu.getDescription() != null) existing.setDescription(menu.getDescription());
        if (menu.getParentMenuId() != null) existing.setParentMenuId(menu.getParentMenuId());
        reconMenuMasterNewRepository.save(existing);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Menu updated successfully.", Collections.singletonList(existing)));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> updateStatus(Long menuId, String status) {
        Optional<ReconMenuMasterNew> opt = reconMenuMasterNewRepository.findById(menuId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Menu not found with ID: " + menuId, null));
        }
        ReconMenuMasterNew existing = opt.get();
        existing.setStatus(status);
        reconMenuMasterNewRepository.save(existing);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Menu status updated.", null));
    }

    @Override
    @Transactional
    public ResponseEntity<RestWithStatusList> deleteMenu(Long menuId) {
        Optional<ReconMenuMasterNew> opt = reconMenuMasterNewRepository.findById(menuId);
        if (!opt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new RestWithStatusList("FAILURE", "Menu not found with ID: " + menuId, null));
        }
        ReconMenuMasterNew existing = opt.get();
        existing.setStatus("INACTIVE");
        reconMenuMasterNewRepository.save(existing);
        return ResponseEntity.ok(new RestWithStatusList("SUCCESS", "Menu deactivated successfully.", null));
    }
}



