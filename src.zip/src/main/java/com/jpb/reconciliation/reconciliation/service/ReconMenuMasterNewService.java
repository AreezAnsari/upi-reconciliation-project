package com.jpb.reconciliation.reconciliation.service;

import com.jpb.reconciliation.reconciliation.dto.RestWithStatusList;
import com.jpb.reconciliation.reconciliation.entity.ReconMenuMasterNew;
import org.springframework.http.ResponseEntity;

public interface ReconMenuMasterNewService {

    ResponseEntity<RestWithStatusList> createMenu(ReconMenuMasterNew menu);

    ResponseEntity<RestWithStatusList> getAllMenus();

    ResponseEntity<RestWithStatusList> getMenuById(Long menuId);

    ResponseEntity<RestWithStatusList> getMenusByStatus(String status);

    ResponseEntity<RestWithStatusList> getMenusByType(String menuType);

    ResponseEntity<RestWithStatusList> getChildMenus(Long parentMenuId);

    ResponseEntity<RestWithStatusList> updateMenu(Long menuId, ReconMenuMasterNew menu);

    ResponseEntity<RestWithStatusList> updateStatus(Long menuId, String status);

    ResponseEntity<RestWithStatusList> deleteMenu(Long menuId);
}
