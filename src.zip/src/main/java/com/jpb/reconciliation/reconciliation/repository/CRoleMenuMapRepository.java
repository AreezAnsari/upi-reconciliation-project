package com.jpb.reconciliation.reconciliation.repository;

import com.jpb.reconciliation.reconciliation.entity.CRoleMenuMap;
import com.jpb.reconciliation.reconciliation.entity.CRoleMenuMap.RoleMenuMapId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CRoleMenuMapRepository extends JpaRepository<CRoleMenuMap, RoleMenuMapId> {

    List<CRoleMenuMap> findByIdRoleId(Long roleId);

    List<CRoleMenuMap> findByIdMenuId(Long menuId);

    void deleteByIdRoleId(Long roleId);

    void deleteByIdMenuId(Long menuId);
}
