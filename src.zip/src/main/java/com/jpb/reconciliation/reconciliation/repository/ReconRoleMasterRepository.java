package com.jpb.reconciliation.reconciliation.repository;

import com.jpb.reconciliation.reconciliation.entity.ReconRoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReconRoleMasterRepository extends JpaRepository<ReconRoleMaster, Long> {

    boolean existsByRoleCode(String roleCode);

    boolean existsByRoleName(String roleName);

    List<ReconRoleMaster> findByStatus(String status);

    List<ReconRoleMaster> findByRoleType(String roleType);
}
