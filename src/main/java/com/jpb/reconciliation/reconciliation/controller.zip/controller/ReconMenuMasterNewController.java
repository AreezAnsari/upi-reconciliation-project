package com.jpb.reconciliation.reconciliation.controller;

import com.jpb.reconciliation.reconciliation.constants.CommonConstants;
import com.jpb.reconciliation.reconciliation.dto.RestWithStatusList;
import com.jpb.reconciliation.reconciliation.entity.ReconMenuMasterNew;
import com.jpb.reconciliation.reconciliation.service.ReconMenuMasterNewService;
import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/menu")
@CrossOrigin(origins = "*")
public class ReconMenuMasterNewController {

    private static final Logger logger = LoggerFactory.getLogger(ReconMenuMasterNewController.class);

    @Autowired
    private ReconMenuMasterNewService reconMenuMasterNewService;

    @Operation(summary = "Create a new menu item")
    @PostMapping(value = "/create", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> createMenu(@RequestBody ReconMenuMasterNew menu) {
        logger.info("Create menu request: {}", menu.getMenuName());
        return reconMenuMasterNewService.createMenu(menu);
    }

    @Operation(summary = "Get all menus")
    @GetMapping(value = "/get-all", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> getAllMenus() {
        return reconMenuMasterNewService.getAllMenus();
    }

    @Operation(summary = "Get menu by ID")
    @GetMapping(value = "/get/{menuId}", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> getMenuById(@PathVariable Long menuId) {
        return reconMenuMasterNewService.getMenuById(menuId);
    }

    @Operation(summary = "Get menus by status")
    @GetMapping(value = "/get-by-status", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> getMenusByStatus(@RequestParam String status) {
        return reconMenuMasterNewService.getMenusByStatus(status);
    }

    @Operation(summary = "Get menus by type")
    @GetMapping(value = "/get-by-type", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> getMenusByType(@RequestParam String menuType) {
        return reconMenuMasterNewService.getMenusByType(menuType);
    }

    @Operation(summary = "Get child menus by parent menu ID")
    @GetMapping(value = "/{parentMenuId}/children", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> getChildMenus(@PathVariable Long parentMenuId) {
        return reconMenuMasterNewService.getChildMenus(parentMenuId);
    }

    @Operation(summary = "Update menu details")
    @PutMapping(value = "/update/{menuId}", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> updateMenu(
            @PathVariable Long menuId,
            @RequestBody ReconMenuMasterNew menu) {
        logger.info("Update menu request for ID: {}", menuId);
        return reconMenuMasterNewService.updateMenu(menuId, menu);
    }

    @Operation(summary = "Update menu status")
    @PatchMapping(value = "/update-status/{menuId}", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> updateStatus(
            @PathVariable Long menuId,
            @RequestParam String status) {
        return reconMenuMasterNewService.updateStatus(menuId, status);
    }

    @Operation(summary = "Soft delete menu")
    @DeleteMapping(value = "/delete/{menuId}", produces = CommonConstants.APPLICATION_JSON)
    public ResponseEntity<RestWithStatusList> deleteMenu(@PathVariable Long menuId) {
        return reconMenuMasterNewService.deleteMenu(menuId);
    }
}
